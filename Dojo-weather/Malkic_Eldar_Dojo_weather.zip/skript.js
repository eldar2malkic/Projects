// --- alert ----

function choseCity() {
    alert("Loading weather report...");
}

//    ---- hide cookies ---

function hideCookies() {
    cookieWindow = document.querySelector("footer");
    cookieWindow.remove();
}
