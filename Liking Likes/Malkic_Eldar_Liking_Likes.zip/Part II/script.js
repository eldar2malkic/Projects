var num1 = 9;
var addLike = document.querySelector("#add");

function add1() {
    num1++;
    addLike.innerText = + num1;
    console.log(num1);
    return(num1);
}

var num2 = 12;
var addaLike = document.querySelector("#adda");

function add2() {
    num2++;
    addaLike.innerText = + num2;
    console.log(num2);
    return(num2);
}

var num3 = 9;
var addbLike = document.querySelector("#addb");

function add3() {
    num3++;
    addbLike.innerText = + num3; 
    console.log(num3);
    return(num3)
}