function play(element) {
    element.play("src","pexels-artem-podrez-6952660.mp4")
}
function pause(element) {
    element.pause("src","pexels-artem-podrez-6952660.mp4")
}
console.log("page loaded...");